# Çekirdek Değişmezler (MUTLAK — hiçbir görev bunları ihlal edemez)

- Hareket hızı HERKES için sabit ve eşit. Sprint, stamina, hız buff'ı,
  refleks bonusu, oyuncu stat farkı ASLA eklenmez. Derinlik fizikten
  gelir (falso, şarj, zamanlama).
- Core (packages/core): saf, el yazması, deterministik, sabit 60Hz
  timestep, DOM'suz, yan etkisiz. WASM fizik motoru (Rapier/Jolt/ammo
  vb.) core'da YASAK — yalnızca kozmetik katmanda kullanılabilir.
- Determinizm kabul kriteri: aynı input dizisi → iki farklı
  cihazda/tarayıcıda bit-özdeş state checksum. Tercih edilen yöntem
  fixed-point aritmetik; nihai karar ADR-0003'te verilir ve bu kriterle
  kanıtlanır.
- Fizik sabitleri brain/20-tech-spec/physics-constants.md'dedir.
  Değişiklik = ADR + constantsHash güncelleme + eski replay'lerin
  açıkça reddedilmesi. Sessiz sabit değişikliği YASAK.
- Kozmetik katman (animasyon, IK, ragdoll, seyirci, sesler, tansiyon,
  kamera, sahneler) core state'ini SADECE OKUR; core'a asla yazmaz.
- Dribbling SAF FİZİK: topa yapışma / magnet / auto-pass ASLA.
- Kaleci MAÇ BAŞINDA SEÇİLİR ve maç boyunca sabittir (ADR-0001).
  Dinamik/otomatik kaleci atama YOK.
- Stadyum editörü / kullanıcı haritası yükleme-paylaşma YOK (ADR-0002).
  Saha boyutları yerleşik preset (K/O/B), görsel temalar yerleşik.
- Grief kilitleri (host doğrular): takım arkadaşına tackle etkisiz;
  kaleci elle tutuştan kendi kalesine gol atamaz.
- MARL eğitimi başladıktan sonra fizik ve oynanış mekanikleri
  DONMUŞTUR; yalnızca kozmetik değişebilir.
- Botlar YALNIZCA host'ta koşar. Netcode host-authoritative'dir.
