# HUMAN-QUEUE — İnsan gerektiren işler (agent bekletmez, buraya yazar)

- [ ] Mixamo animasyon paketi indirme (Adobe hesabı gerekir) —
      asset-artist liste verecek, indirilen dosya yolları buraya yazılacak
- [ ] (OS yönetici onayı gerektiren kurulum çıkarsa devops ekler)
